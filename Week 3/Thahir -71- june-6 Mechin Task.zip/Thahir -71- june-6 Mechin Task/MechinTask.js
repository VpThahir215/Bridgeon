//Question 1

function toArray(...a){
console.log(a);

}
toArray({a:1,b:2})


//Question 3

function replaceSpace(a){
let b=a.split(" ")
console.log(b.join("+"));

}
replaceSpace("i love JS")


//Question 2

function moveCapital(a){
    let cap="";
for(let i =0 ; i<a.lenght;i++){
    if(a[i]==="A"){
        cap+=
    }
    
}

console.log(cap);

}

moveCapital("PyTHon")